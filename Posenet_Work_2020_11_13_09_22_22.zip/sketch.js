let video;
let poseNet;
let noseX = 0;
let noseY = 0;
let leyeX = 0;
let leyeY = 0;
let reyeX = 0;
let reyeY = 0;
let line1 = 300;

function setup() {
  //here I setted up the video frame for the Posenet stuff
  createCanvas(640, 480);
  video = createCapture(VIDEO);
  //I hid this because there's actually two video displays: one in setup() and other one in draw()
  video.hide();
  video.size(width, height);
  poseNet = ml5.poseNet(video, modelReady)
  poseNet.on('pose', gotPoses);
}

function gotPoses(poses) {
  //I used a loop to check through the poses
  if (poses.length > 0) {
    let newnoseX = poses[0].pose.keypoints[0].position.x;
    let newnoseY = poses[0].pose.keypoints[0].position.y;
    //here I used lerp() to stablize the movement of the points so it didn't move around so much
    noseX = lerp(noseX, newnoseX, 0.35);
    noseY = lerp(noseY, newnoseY, 0.35);
    
    //I called the keypoints[1] because keypoints[0] was for nose
    let newleyeX = poses[0].pose.keypoints[1].position.x;
    let newleyeY = poses[0].pose.keypoints[1].position.y;
    leyeX = lerp(leyeX, newleyeX, 0.35);
    leyeY = lerp(leyeY, newleyeY, 0.35);
    
    let newreyeX = poses[0].pose.keypoints[2].position.x;
    let newreyeY = poses[0].pose.keypoints[2].position.y;
    reyeX = lerp(reyeX, newreyeX, 0.35);
    reyeY = lerp(reyeY, newreyeY, 0.35);
  }
}

function modelReady() {
  console.log('model ready');
}

function draw() {
  image(video, 0, 0);
  
  //adding this allows for the ellipses of the three points to change sizes are you get closer or further away from the screen
  //I didn't aadd reyeX and reyeY to dist() because the eyes are symmetrical so it wouldn't really matter
  let distance = dist(noseX, noseY, leyeX, leyeY);
  
  //I've only made the size change for the nose
  if (noseX > line1) {
    fill(0, 255, 0);
  }
  else {
    fill(255, 0, 0);
  }
  ellipse(noseX, noseY, distance);
  
  if (leyeX > line1) {
    fill(0, 255, 0);
  }
  else {
    fill(255, 0, 0);
  }
  ellipse(leyeX, leyeY, 20);
  
  if (reyeX > line1) {
    fill(0, 255, 0);
  }
  else {
    fill(255, 0, 0);
  }
  ellipse(reyeX, reyeY, 20);
  
  fill(56);
  line(300, 0,300, height);
}